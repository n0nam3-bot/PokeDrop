// PokeDrop v4 discovery/enrichment.
// Entry URLs are saved only after the destination itself is fetched and verified as a
// Pokémon TCG giveaway page. Generic platform links, favicons and unrelated article images
// are never treated as prize/item images.
import { readFileSync, writeFileSync } from "node:fs";

const RESOLVER_VERSION = 4;
const MAX_RAFFLE_CHECKS_PER_RUN = 40;
const MAX_POST_IMAGE_CHECKS_PER_RUN = 40;
const CONCURRENCY = 4;
const FETCH_TIMEOUT_MS = 14000;
const MAX_IMAGES_PER_ITEM = 6;

function readJson(file, fallback) {
  try { return JSON.parse(readFileSync(file, "utf8")); } catch { return fallback; }
}
function writeJson(file, value) {
  writeFileSync(file, `${JSON.stringify(value, null, 1)}\n`);
}
function decodeEntities(value) {
  return String(value || "")
    .replace(/&(#x[\da-f]+|#\d+|amp|lt|gt|quot|apos|nbsp);/gi, (whole, entity) => {
      const key = entity.toLowerCase();
      if (key === "amp") return "&";
      if (key === "lt") return "<";
      if (key === "gt") return ">";
      if (key === "quot") return '"';
      if (key === "apos") return "'";
      if (key === "nbsp") return " ";
      if (key.startsWith("#x")) return String.fromCodePoint(parseInt(key.slice(2), 16));
      if (key.startsWith("#")) return String.fromCodePoint(parseInt(key.slice(1), 10));
      return whole;
    });
}
function stripMarkup(value) {
  return decodeEntities(value)
    .replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi, " ")
    .replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi, " ")
    .replace(/<noscript\b[^>]*>[\s\S]*?<\/noscript>/gi, " ")
    .replace(/<[^>]+>/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}
function attr(attributes, name) {
  const escaped = name.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const match = String(attributes || "").match(new RegExp(`\\b${escaped}\\s*=\\s*(?:"([^"]*)"|'([^']*)'|([^\\s>]+))`, "i"));
  return match ? decodeEntities(match[1] ?? match[2] ?? match[3] ?? "") : "";
}
function resolveUrl(raw, base) {
  try {
    const value = decodeEntities(String(raw || "").replace(/\\\//g, "/").trim());
    if (!value || /^(?:javascript|mailto|tel|data):/i.test(value)) return "";
    let parsed = new URL(value, base);
    if (/((^|\.)google\.[a-z.]+$)/i.test(parsed.hostname) && ["/url", "/redirect"].includes(parsed.pathname)) {
      const wrapped = parsed.searchParams.get("q") || parsed.searchParams.get("url") || parsed.searchParams.get("u") || parsed.searchParams.get("redirect_url") || parsed.searchParams.get("dest");
      if (wrapped) parsed = new URL(wrapped);
    }
    return /^https?:$/.test(parsed.protocol) ? parsed.href : "";
  } catch { return ""; }
}
function isGoogleHost(host) {
  return /(^|\.)google\.[a-z.]+$/i.test(String(host || "")) || /(^|\.)news\.google\.com$/i.test(String(host || ""));
}
function isEntryPlatform(host) {
  return /(^|\.)(gleam\.io|sweepwidget\.com|rafflecopter\.com|raffall\.com|rafflepress\.com|rafflebox\.us|rafflecreator\.com|viral-sweep\.com|viralsweep\.com|sweeppea\.com|easypromosapp\.com|woobox\.com|shortstack\.com|kingsumo\.com|giveawaytools\.com|promosimple\.com|typeform\.com|jotform\.com)$/i.test(String(host || ""));
}
function metaValue(html, names) {
  const wanted = new Set(names.map((item) => item.toLowerCase()));
  for (const [, raw] of String(html || "").matchAll(/<meta\b([^>]*)>/gi)) {
    const key = (attr(raw, "property") || attr(raw, "name") || attr(raw, "itemprop")).toLowerCase();
    if (wanted.has(key)) {
      const value = attr(raw, "content");
      if (value) return value;
    }
  }
  return "";
}
function titleTag(html) {
  const match = String(html || "").match(/<title\b[^>]*>([\s\S]*?)<\/title>/i);
  return match ? stripMarkup(match[1]) : "";
}
function pageText(html) {
  return stripMarkup(String(html || "")
    .replace(/<nav\b[^>]*>[\s\S]*?<\/nav>/gi, " ")
    .replace(/<footer\b[^>]*>[\s\S]*?<\/footer>/gi, " "));
}
function canonicalUrl(html, fallback) {
  for (const [, raw] of String(html || "").matchAll(/<link\b([^>]*)>/gi)) {
    if (/\bcanonical\b/i.test(attr(raw, "rel"))) {
      const candidate = resolveUrl(attr(raw, "href"), fallback);
      if (candidate) return candidate;
    }
  }
  for (const [, raw] of String(html || "").matchAll(/<meta\b([^>]*)>/gi)) {
    const key = attr(raw, "property") || attr(raw, "name");
    if (/^(?:og:url|twitter:url)$/i.test(key)) {
      const candidate = resolveUrl(attr(raw, "content"), fallback);
      if (candidate) return candidate;
    }
  }
  return fallback;
}
function flattenJsonLd(value, out = []) {
  if (Array.isArray(value)) {
    for (const item of value) flattenJsonLd(item, out);
  } else if (value && typeof value === "object") {
    out.push(value);
    for (const [key, nested] of Object.entries(value)) {
      if (nested && typeof nested === "object") flattenJsonLd(nested, out);
    }
  }
  return out;
}
function jsonLdNodes(html) {
  const nodes = [];
  for (const [, attributes, raw] of String(html || "").matchAll(/<script\b([^>]*)>([\s\S]*?)<\/script>/gi)) {
    if (!/application\/ld\+json/i.test(attr(attributes, "type"))) continue;
    const content = decodeEntities(raw.replace(/^\s*<!--|-->\s*$/g, "").trim());
    try { flattenJsonLd(JSON.parse(content), nodes); } catch { /* ignore malformed publisher data */ }
  }
  return nodes;
}
function typeIncludes(node, type) {
  const value = node?.["@type"];
  return (Array.isArray(value) ? value : [value]).some((item) => String(item || "").toLowerCase().includes(type.toLowerCase()));
}
function firstText(...values) {
  for (const value of values) {
    if (typeof value === "string" && value.trim()) return stripMarkup(value).slice(0, 300);
    if (Array.isArray(value)) {
      const inner = firstText(...value);
      if (inner) return inner;
    }
    if (value && typeof value === "object") {
      const inner = firstText(value.name, value.text, value.description, value.url);
      if (inner) return inner;
    }
  }
  return "";
}
function normalizeDate(value) {
  if (!value) return "";
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? "" : date.toISOString();
}
function dateFromText(text, kind) {
  const month = "(?:Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:tember)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)";
  const date = `(${month}\\s+\\d{1,2}(?:st|nd|rd|th)?(?:,?\\s+\\d{4})?|\\d{1,2}\\/\\d{1,2}(?:\\/\\d{2,4})?)`;
  // Deliberately require giveaway/entry wording. Product release dates are NOT raffle dates.
  const patterns = kind === "end"
    ? [
        `(?:entries? (?:close|end)|entry (?:closes|ends)|(?:giveaway|raffle|sweepstakes|contest) (?:closes|ends)|entry deadline|last day to enter|deadline to enter)\\s*(?:on|by|at)?\\s*${date}`,
        `${date}\\s*(?:is the )?(?:entry deadline|last day to enter)`
      ]
    : [
        `(?:entries? open|registration opens?|(?:giveaway|raffle|sweepstakes|contest) (?:opens|starts|begins))\\s*(?:on|at)?\\s*${date}`
      ];
  for (const pattern of patterns) {
    const match = String(text || "").match(new RegExp(pattern, "i"));
    if (!match) continue;
    let raw = (match[1] || match[0]).replace(/(\d)(st|nd|rd|th)\b/i, "$1");
    const hasYear = /\b\d{4}\b/.test(raw) || /\d{1,2}\/\d{1,2}\/\d{2,4}/.test(raw);
    if (!hasYear) raw += ` ${new Date().getFullYear()}`;
    const parsed = normalizeDate(raw);
    if (parsed) return parsed;
  }
  return "";
}

const PROMOTION_RE = /\b(raffle|giveaway|give aways|give away|sweepstakes|enter to win|contest|drawing|lottery|prize draw)\b/i;
const POKEMON_RE = /\b(pok[eé]mon)\b/i;
const TCG_PRODUCT_RE = /\b(tcg|trading cards?|pok[eé]mon cards?|booster (?:box|packs?)|elite trainer boxes?|\betb\b|promo cards?|collector(?:'s)? boxes?|pok[eé]mon (?:collection|tins?)|sealed (?:pokemon|tcg))\b/i;
const CRIME_RE = /\b(theft|stolen|stealing|stole|shoplifting|robbery|robbed|arrested|arrest|suspect|charged with|police investigate|fraud case|burglar)\b/i;
const MONEY_PRIZE_RE = /\b(gift cards?|gift certificates?|cash prize|cash|money|store credit|prepaid cards?|visa gift|mastercard gift|paypal credit)\b/i;
const PHYSICAL_PRIZE_RE = /\b(pok[eé]mon cards?|trading cards?|booster|elite trainer|etb|promo cards?|collector box|sealed product|mini tins?|collection box)\b/i;
function isTcgGiveawayText(value) {
  const text = String(value || "");
  if (CRIME_RE.test(text)) return false;
  return POKEMON_RE.test(text) && TCG_PRODUCT_RE.test(text) && PROMOTION_RE.test(text);
}
function isMoneyOnlyPrize(prize) {
  const value = String(prize || "");
  return MONEY_PRIZE_RE.test(value) && !PHYSICAL_PRIZE_RE.test(value);
}
function prizeHintFromText(value) {
  const text = String(value || "");
  const patterns = [
    /(?:grand prize|prize package|the prize|prizes include|winner receives|winner will receive|giveaway prize|prize is|prize:|win(?:s|ning)?\s+(?:a|an|the)?)\s*([^.!?]{4,180})/i,
    /(?:winner gets|winner takes home)\s+([^.!?]{4,180})/i
  ];
  for (const pattern of patterns) {
    const match = text.match(pattern);
    if (match?.[1]) return match[1].replace(/\b(enter now|register now|sign up|submit entry|official rules|read more)\b.*$/i, "").trim();
  }
  if (MONEY_PRIZE_RE.test(text) && !PHYSICAL_PRIZE_RE.test(text)) return text.slice(0, 180);
  return "";
}
function imageAllowed(url, alt = "") {
  try {
    const parsed = new URL(url);
    if (!/^https?:$/.test(parsed.protocol)) return false;
    const path = `${parsed.pathname} ${parsed.search}`.toLowerCase();
    const description = String(alt || "").toLowerCase();
    if (/favicon|apple-touch-icon|site[-_]?logo|logo[-_]?|[-_/]logo(?:[-_.?/]|$)|icon|avatar|profile|sprite|brandmark|placeholder|default[-_]?image|social[-_]?icon|badge|author/i.test(path)) return false;
    if (/\b(site logo|company logo|brand logo|favicon|site icon|author photo|profile picture|avatar)\b/i.test(description)) return false;
    if (/\.(?:ico|svg)(?:$|\?)/i.test(path)) return false;
    if (/^(?:data|blob):/i.test(url)) return false;
    return true;
  } catch { return false; }
}
function imageUrlFrom(value, base) {
  if (Array.isArray(value)) {
    for (const item of value) { const candidate = imageUrlFrom(item, base); if (candidate) return candidate; }
    return "";
  }
  if (value && typeof value === "object") return imageUrlFrom(value.url || value.contentUrl || value.thumbnailUrl, base);
  const url = resolveUrl(value, base);
  return url && imageAllowed(url) ? url : "";
}
function uniqueImages(items) {
  const seen = new Set();
  return items.filter((item) => {
    if (!item?.url || !imageAllowed(item.url, item.alt || "")) return false;
    const key = item.url.split(/[?#]/)[0].toLowerCase();
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  }).slice(0, MAX_IMAGES_PER_ITEM);
}
function extractItemImages(html, pageUrl, subjectText, mode = "post", event = null, product = null, allowProductOg = false) {
  const candidates = [];
  const subject = String(subjectText || "").toLowerCase();
  const hasPokemonSubject = POKEMON_RE.test(subject);
  const add = (raw, label, kind, alt = "") => {
    const url = resolveUrl(raw, pageUrl);
    if (!url || !imageAllowed(url, alt)) return;
    candidates.push({ url, label, kind, alt: String(alt || "").slice(0, 180) });
  };

  const productText = `${product?.name || ""} ${product?.description || ""}`;
  const productMatchesTcg = product && TCG_PRODUCT_RE.test(productText)
    && (POKEMON_RE.test(productText) || (hasPokemonSubject && TCG_PRODUCT_RE.test(subject)));
  if (productMatchesTcg) {
    const raw = product.image;
    const urls = Array.isArray(raw) ? raw : [raw];
    for (const image of urls) add(image?.url || image?.contentUrl || image, "PRODUCT IMAGE", "product", product.name || "Pokémon TCG product");
  }
  if (event && mode === "raffle") {
    const raw = event.image;
    const urls = Array.isArray(raw) ? raw : [raw];
    for (const image of urls) add(image?.url || image?.contentUrl || image, "GIVEAWAY IMAGE", "event", event.name || "Pokémon TCG giveaway");
  }

  for (const match of String(html || "").matchAll(/<img\b([^>]*)>/gi)) {
    const raw = match[1];
    const alt = attr(raw, "alt") || attr(raw, "title");
    const width = Number(attr(raw, "width"));
    const height = Number(attr(raw, "height"));
    if ((width && width < 96) || (height && height < 96)) continue;
    const before = String(html || "").slice(Math.max(0, match.index - 1400), match.index);
    const after = String(html || "").slice(match.index + match[0].length, Math.min(String(html || "").length, match.index + match[0].length + 700));
    const figureStart = before.lastIndexOf("<figure");
    const figureEnd = after.indexOf("</figure>");
    const figureContext = figureStart >= 0 && figureEnd >= 0
      ? `${before.slice(figureStart)} ${after.slice(0, figureEnd)}`
      : `${before.slice(-500)} ${after.slice(0, 250)}`;
    const elementContext = `${alt} ${attr(raw, "data-caption")} ${attr(raw, "aria-label")} ${attr(raw, "data-product-title")} ${attr(raw, "class")} ${stripMarkup(figureContext)}`;
    const url = attr(raw, "data-zoom-image") || attr(raw, "data-product-image") || attr(raw, "data-src") || attr(raw, "data-lazy-src") || attr(raw, "data-original") || attr(raw, "src");
    const srcset = attr(raw, "srcset");
    const largestSrc = srcset.split(",").map((part) => {
      const bits = part.trim().split(/\s+/);
      const descriptor = bits[1] || "";
      const size = Number.parseInt(descriptor, 10) || 0;
      return { url: bits[0], size };
    }).filter((part) => part.url).sort((a, b) => b.size - a.size)[0]?.url;
    const chosen = largestSrc || url;
    const hasPhysicalItemClue = /pok[eé]mon cards?|trading cards?|booster|elite trainer|\betb\b|promo cards?|collection box|mini tin|sealed product|starter deck|tcg product/i.test(elementContext);
    const titleOverlap = subject.split(/[^a-z0-9]+/).filter((word) => word.length > 4 && !["pokemon", "pokémon", "giveaway", "raffle", "trading", "cards"].includes(word)).some((word) => elementContext.toLowerCase().includes(word));
    const urlLooksLikeItem = /pokemon|pok[eé]mon|trading.card|booster|elite.trainer|\betb\b|promo.card|collection.box|mini.tin|starter.deck/i.test(chosen);
    const relevant = mode === "raffle" ? (hasPhysicalItemClue || urlLooksLikeItem) : (hasPhysicalItemClue || titleOverlap || urlLooksLikeItem);
    if (relevant) add(chosen, "ITEM IMAGE", "product", alt || stripMarkup(figureContext).slice(0, 140) || "Pokémon TCG item");
  }

  // An OG preview is a last-resort editorial thumbnail for regular alerts only. It is
  // never passed off as a raffle prize image and never uses favicon/icon metadata.
  if (mode === "post" && !candidates.length) {
    const ogAlt = metaValue(html, ["og:image:alt", "twitter:image:alt"]);
    const ogUrl = metaValue(html, ["og:image", "og:image:url", "twitter:image", "twitter:image:src"]);
    const ogWidth = Number(metaValue(html, ["og:image:width", "twitter:image:width"]) || 0);
    const ogHeight = Number(metaValue(html, ["og:image:height", "twitter:image:height"]) || 0);
    const largeEnough = (!ogWidth || ogWidth >= 200) && (!ogHeight || ogHeight >= 160);
    if (ogUrl && largeEnough && imageAllowed(resolveUrl(ogUrl, pageUrl), ogAlt)) {
      const fileLooksRelevant = /pokemon|pok[eé]mon|tcg|card|booster|etb|collection|tin|promo/i.test(ogUrl);
      if (fileLooksRelevant || (hasPokemonSubject && /pokemon|pok[eé]mon|tcg|card|booster|etb|collection|tin|promo/i.test(ogAlt))) {
        add(ogUrl, "ARTICLE IMAGE", "article", ogAlt || "Related Pokémon TCG article image");
      }
    }
  }
  // A confirmed retailer/product page can use its large OG image as the product photo
  // when the publisher omits schema.org Product.image and image alt text.
  if (mode === "post" && allowProductOg && !candidates.length) {
    const productPageTitle = `${titleTag(html)} ${metaValue(html, ["og:title", "og:description", "description"])}`;
    const ogUrl = metaValue(html, ["og:image", "og:image:url", "twitter:image", "twitter:image:src"]);
    const ogAlt = metaValue(html, ["og:image:alt", "twitter:image:alt"]) || productPageTitle;
    const ogWidth = Number(metaValue(html, ["og:image:width", "twitter:image:width"]) || 0);
    const ogHeight = Number(metaValue(html, ["og:image:height", "twitter:image:height"]) || 0);
    if (ogUrl && (!ogWidth || ogWidth >= 200) && (!ogHeight || ogHeight >= 160)
      && imageAllowed(resolveUrl(ogUrl, pageUrl), ogAlt)) {
      add(ogUrl, "PRODUCT IMAGE", "product", ogAlt);
    }
  }
  return uniqueImages(candidates);
}
function extractPageMetadata(html, pageUrl, raffle) {
  const nodes = jsonLdNodes(html);
  const allEvents = nodes.filter((node) => typeIncludes(node, "Event") || typeIncludes(node, "Contest"));
  const event = allEvents.find((node) => PROMOTION_RE.test(`${node.name || ""} ${node.description || ""} ${node.award || ""} ${node.prize || ""}`)) || null;
  const products = nodes.filter((node) => typeIncludes(node, "Product"));
  const product = products.find((node) => TCG_PRODUCT_RE.test(`${node.name || ""} ${node.description || ""}`)
    && (POKEMON_RE.test(`${node.name || ""} ${node.description || ""}`)
      || (POKEMON_RE.test(`${raffle?.title || ""} ${raffle?.summary || ""} ${titleTag(html)}`)
        && TCG_PRODUCT_RE.test(`${raffle?.title || ""} ${raffle?.summary || ""} ${titleTag(html)}`)))) || null;
  const website = nodes.find((node) => typeIncludes(node, "WebSite")) || {};
  const organization = nodes.find((node) => typeIncludes(node, "Organization")) || {};
  const publisher = nodes.find((node) => node?.publisher) || {};
  const text = pageText(html);
  const pageTitle = firstText(metaValue(html, ["og:title", "twitter:title"]), titleTag(html), event?.name, product?.name, nodes.find((node) => node.headline)?.headline);
  const pageDescription = firstText(metaValue(html, ["og:description", "description", "twitter:description"]), event?.description, product?.description, nodes.find((node) => node.description)?.description);
  let host = "";
  let origin = "";
  try { const parsed = new URL(pageUrl); host = parsed.hostname.replace(/^www\./, ""); origin = parsed.origin; } catch { /* keep empty */ }
  const siteName = firstText(metaValue(html, ["og:site_name", "application-name"]), website.name, organization.name, publisher.publisher?.name, host);

  const allowedStructuredDates = Boolean(event);
  const startDate = (allowedStructuredDates ? normalizeDate(event.startDate) : "") || dateFromText(text, "start");
  const endDate = (allowedStructuredDates ? normalizeDate(event.endDate || event.offers?.validThrough) : "") || dateFromText(text, "end");

  let prize = "";
  if (event && isTcgGiveawayText(`${event.name || ""} ${event.description || ""} ${event.award || ""} ${event.prize || ""} ${raffle?.title || ""}`)) {
    prize = firstText(event.award, event.prize);
  }
  if (!prize && product && isTcgGiveawayText(`${pageTitle} ${pageDescription} ${text} ${raffle?.title || ""} ${raffle?.summary || ""}`)) {
    prize = firstText(product.name);
  }
  if (!prize) {
    const prizePatterns = [
      /(?:grand prize|prize package|the prize|prizes include|winner receives|winner will receive|giveaway prize|prize is|prize:|win(?:s|ning)?\s+(?:a|an|the)?)\s*([^.!?]{5,180})/i,
      /(?:winner gets|winner takes home)\s+([^.!?]{5,180})/i
    ];
    for (const pattern of prizePatterns) {
      const match = text.match(pattern);
      if (match?.[1]) { prize = match[1].replace(/\b(enter now|register now|sign up|submit entry|official rules|read more)\b.*$/i, "").replace(/\s+/g, " ").trim().slice(0, 180); break; }
    }
  }

  const isGiveawayContext = isTcgGiveawayText(`${raffle?.title || ""} ${raffle?.summary || ""} ${pageTitle} ${pageDescription} ${text}`);
  const images = extractItemImages(html, pageUrl, `${raffle?.title || ""} ${raffle?.summary || ""} ${pageTitle}`, "raffle", event, product);
  const prizeImages = images.filter((image) => image.kind === "product");
  const prizeImage = prizeImages[0] || null;
  const prizeTextHint = prizeHintFromText(text);
  const extractedPrize = prizeTextHint || prize;
  return {
    pageTitle,
    pageDescription,
    siteName,
    siteUrl: origin,
    startDate,
    endDate,
    prize: extractedPrize.replace(/\s+/g, " ").trim().slice(0, 180),
    imageUrl: isGiveawayContext ? prizeImage?.url || "" : "",
    imageType: prizeImage ? "prize" : "",
    imageUrls: isGiveawayContext ? prizeImages : [],
    structuredEvent: Boolean(event),
    structuredProduct: Boolean(product),
    relevant: isGiveawayContext && !CRIME_RE.test(`${pageTitle} ${pageDescription} ${text}`),
    cashOnlyPrize: isMoneyOnlyPrize(prizeTextHint) || isMoneyOnlyPrize(prize)
  };
}
function dateStatus(startDate, endDate, text, publishedDate) {
  const now = Date.now();
  const start = Date.parse(startDate || "");
  const end = Date.parse(endDate || "");
  if (Number.isFinite(end) && end < now) return { status: "Closed", statusDate: endDate, statusNote: "The verified entry deadline has passed." };
  if (Number.isFinite(start) && start > now) return { status: "Upcoming", statusDate: startDate, statusNote: "Entries have a verified future opening date." };
  if (Number.isFinite(end) && end >= now) return { status: "Open", statusDate: endDate, statusNote: "The verified deadline is still in the future." };
  const body = String(text || "");
  if (/\b(entries? (?:are )?closed|no longer accepting entries|winners? (?:were )?(?:announced|selected|drawn)|giveaway ended|raffle ended|sweepstakes ended|deadline (?:has )?passed)\b/i.test(body)) {
    return { status: "Closed", statusDate: "", statusNote: "The page says entries have closed or winners were selected." };
  }
  if (/\b(enter now|entries? (?:are )?open|giveaway is live|raffle is live|registration is open|register now|enter to win now)\b/i.test(body)) {
    return { status: "Open", statusDate: "", statusNote: "The page indicates entries are open, but does not publish a verified deadline." };
  }
  // A publication date or a product-release date must never make a giveaway Upcoming.
  return { status: "Verify", statusDate: "", statusNote: "The giveaway is relevant, but its entry window could not be verified." };
}
async function fetchHtml(url) {
  const response = await fetch(url, {
    redirect: "follow",
    headers: {
      "user-agent": "Mozilla/5.0 (compatible; PokeDropRaffleRadar/4.0; +https://github.com/n0nam3-bot/PokeDrop)",
      accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
    },
    signal: AbortSignal.timeout(FETCH_TIMEOUT_MS)
  });
  if (!response.ok) throw new Error(`HTTP ${response.status}`);
  const contentType = response.headers.get("content-type") || "";
  if (contentType && !/(text\/html|application\/xhtml\+xml)/i.test(contentType)) throw new Error(`Not an HTML page (${contentType})`);
  return { html: (await response.text()).slice(0, 3000000), url: response.url || url };
}
function findPublisherArticleInGooglePage(html, googleUrl, publisherUrl) {
  let publisherHost = "";
  try { publisherHost = new URL(publisherUrl).hostname.toLowerCase().replace(/^www\./, ""); } catch { return ""; }
  // Google News sometimes exposes the article only through canonical/OG metadata.
  const canonical = canonicalUrl(html, googleUrl);
  try {
    const canonicalHost = new URL(canonical).hostname.toLowerCase().replace(/^www\./, "");
    if (!isGoogleHost(canonicalHost) && (canonicalHost === publisherHost || canonicalHost.endsWith(`.${publisherHost}`))) return canonical;
  } catch { /* keep searching anchors */ }
  for (const [, attributes, inner] of String(html || "").matchAll(/<a\b([^>]*)>([\s\S]*?)<\/a>/gi)) {
    const href = resolveUrl(attr(attributes, "href") || attr(attributes, "data-href"), googleUrl);
    if (!href) continue;
    try {
      const parsed = new URL(href);
      const candidateHost = parsed.hostname.toLowerCase().replace(/^www\./, "");
      if (candidateHost !== publisherHost && !candidateHost.endsWith(`.${publisherHost}`)) continue;
      if (parsed.pathname === "/" || /\/(?:search|author|category|tag|feed)(?:\/|$)/i.test(parsed.pathname)) continue;
      if (stripMarkup(inner).length || parsed.pathname.split("/").filter(Boolean).length >= 1) return parsed.href;
    } catch { /* ignore malformed wrapper links */ }
  }
  return "";
}
async function fetchPublisherArticle(item) {
  const sourceUrl = String(item.sourceUrl || item.url || "").trim();
  const publisherUrl = String(item.publisherUrl || "").trim();
  if (!/^https?:\/\//i.test(sourceUrl)) throw new Error("No source article URL was available.");
  let page = await fetchHtml(sourceUrl);
  if (isGoogleHost(new URL(page.url).hostname)) {
    const articleUrl = findPublisherArticleInGooglePage(page.html, page.url, publisherUrl);
    if (articleUrl) page = await fetchHtml(articleUrl);
    else {
      // A publisher homepage is not a substitute for the individual article page.
      let hasArticlePath = false;
      try { hasArticlePath = Boolean(new URL(publisherUrl).pathname.replace(/\/$/, "")); } catch { /* ignore */ }
      if (hasArticlePath) page = await fetchHtml(publisherUrl);
      else throw new Error("Google News did not expose the publisher article destination.");
    }
  }
  if (isGoogleHost(new URL(page.url).hostname)) throw new Error("Could not resolve Google News to a publisher article.");
  const path = new URL(page.url).pathname;
  if (path === "/" && publisherUrl && new URL(publisherUrl).pathname === "/") {
    throw new Error("Only a publisher homepage was available; no article page was resolved.");
  }
  return page;
}
function entryCandidates(html, pageUrl, raffle) {
  const source = String(html || "");
  const bodyText = pageText(source);
  const articleContext = `${raffle?.title || ""} ${raffle?.summary || ""} ${titleTag(source)} ${metaValue(source, ["og:description", "description"])} ${bodyText}`;
  if (!isTcgGiveawayText(articleContext)) return [];
  const pageHost = new URL(pageUrl).hostname.toLowerCase();
  const candidates = [];
  const add = (raw, label, context, kind = "anchor") => {
    const url = resolveUrl(raw, pageUrl);
    if (!url) return;
    let parsed;
    try { parsed = new URL(url); } catch { return; }
    if (isGoogleHost(parsed.hostname) || parsed.hostname.toLowerCase() === pageHost) return;
    const platform = isEntryPlatform(parsed.hostname);
    const combined = `${label || ""} ${context || ""} ${parsed.pathname}`.toLowerCase();
    const action = /\b(enter(?: now| here| to win)?|submit (?:your )?entr(?:y|ies)|register(?: now)?|join (?:the )?(?:giveaway|raffle|contest)|participate|sign up|entry form|apply now|click (?:here|to enter)|giveaway entry)\b/.test(String(label || "").toLowerCase());
    const contestPath = /raffle|giveaway|sweepstakes|contest|lottery|(?:^|\/)(?:entry|enter)(?:\/|$)|enter-to-win/i.test(combined);
    const rulesOnly = /official rules|terms and conditions|privacy policy|learn more about/i.test(String(label || "")) && !action;
    const pathLooksLikeArticle = /\/(?:news|article|articles|blog|press-release|stories)\//i.test(parsed.pathname);
    const validCandidate = !rulesOnly && !pathLooksLikeArticle && (platform || action || contestPath || kind === "iframe" || kind === "form");
    if (validCandidate) candidates.push({ url: parsed.href, label: String(label || (platform ? "Giveaway platform" : "Entry link")).slice(0, 100), score: (platform ? 9 : 0) + (action ? 8 : 0) + (contestPath ? 5 : 0) + (kind === "iframe" ? 2 : 0) + (kind === "form" ? 3 : 0) });
  };
  for (const match of source.matchAll(/<a\b([^>]*)>([\s\S]*?)<\/a>/gi)) {
    const attrs = match[1];
    const label = stripMarkup(match[2]) || attr(attrs, "aria-label") || attr(attrs, "title");
    const context = stripMarkup(source.slice(Math.max(0, match.index - 400), Math.min(source.length, match.index + match[0].length + 400)));
    add(attr(attrs, "href") || attr(attrs, "data-href") || attr(attrs, "data-url") || attr(attrs, "data-link"), label, context);
    const onclick = attr(attrs, "onclick");
    const jsUrl = onclick.match(/(?:location\.href|window\.open|href)\s*[:=(]\s*["']([^"']+)["']/i)?.[1];
    if (jsUrl) add(jsUrl, label, context);
  }
  for (const match of source.matchAll(/<iframe\b([^>]*)>/gi)) {
    const attrs = match[1];
    add(attr(attrs, "src") || attr(attrs, "data-src"), attr(attrs, "title") || "Embedded entry form", bodyText, "iframe");
  }
  for (const match of source.matchAll(/<form\b([^>]*)>/gi)) {
    const attrs = match[1];
    add(attr(attrs, "action"), "Entry form", bodyText, "form");
  }
  // Entry platform URLs are frequently embedded in widget configuration rather than anchors.
  for (const match of source.matchAll(/https?:\\?\/\\?\/[^\s"'<>\\]+/gi)) {
    const raw = match[0].replace(/\\\//g, "/").replace(/\\u0026/gi, "&").replace(/[),;]+$/, "");
    if (/gleam\.io|sweepwidget\.com|rafflecopter\.com|raffall\.com|viralsweep\.com|viral-sweep\.com|woobox\.com|easypromosapp\.com|shortstack\.com|promosimple\.com/i.test(raw)) {
      add(raw, "Embedded giveaway platform", bodyText, "script");
    }
  }
  return candidates.sort((a, b) => b.score - a.score).filter((item, index, list) => list.findIndex((other) => other.url === item.url) === index);
}
function entryPageValid(url, html, raffle) {
  const host = (() => { try { return new URL(url).hostname; } catch { return ""; } })();
  const body = pageText(html);
  // Ignore scripts and embedded JSON when judging destination relevance. This prevents an
  // unrelated page from passing simply because a widget/config contains Pokémon keywords.
  const headings = `${titleTag(html)} ${metaValue(html, ["og:title", "og:description", "description", "twitter:title", "twitter:description"])}`;
  const visibleDetails = `${headings} ${body}`;
  if (body.length < 35 || !isTcgGiveawayText(visibleDetails)) return false;
  if (CRIME_RE.test(visibleDetails)) return false;
  const prizeHint = prizeHintFromText(visibleDetails);
  if (isMoneyOnlyPrize(raffle?.prize) || isMoneyOnlyPrize(prizeHint)) return false;
  const forms = [...String(html || "").matchAll(/<form\b([^>]*)>([\s\S]*?)<\/form>/gi)];
  const hasVerifiedEntryForm = forms.some(([, attributes, content]) => {
    const formText = `${attr(attributes, "action")} ${stripMarkup(content)}`;
    const hasEntryWords = /\b(enter|entry|submit|giveaway|raffle|sweepstakes|contest|participate|register)\b/i.test(formText);
    const hasControl = /<(?:input|button|select)\b|type\s*=\s*["']?submit/i.test(content);
    return hasEntryWords && hasControl;
  });
  const platformHasEntryAction = isEntryPlatform(host)
    && /\b(enter now|enter here|enter to win|submit entry|register now|join giveaway|giveaway is live|raffle is live|start entry)\b/i.test(body);
  return hasVerifiedEntryForm || platformHasEntryAction;
}
function storeFromText(text, fallback) {
  const haystack = String(text || "");
  const patterns = [
    ["Pokémon Center", /pok[eé]mon\s*center|pokemon\.com/i], ["Target", /\btarget\b/i],
    ["Walmart", /\bwalmart\b/i], ["Costco", /\bcostco\b/i], ["GameStop", /game\s*stop/i],
    ["Best Buy", /best\s*buy/i], ["Amazon", /\bamazon\b/i], ["Sam's Club", /sam'?s\s*club/i],
    ["TCGplayer", /tcgplayer/i], ["Local Card Shop", /card\s*shop|game\s*store|\bLGS\b/i]
  ];
  return patterns.find(([, regex]) => regex.test(haystack))?.[0] || fallback || "Other";
}
function inferStatus(startDate, endDate, bodyText) {
  const now = Date.now();
  const start = Date.parse(startDate || "");
  const end = Date.parse(endDate || "");
  const body = String(bodyText || "");
  const explicitlyClosed = /\b(entries? (?:are )?closed|no longer accepting entries|winners? (?:were )?(?:announced|selected|drawn)|giveaway ended|raffle ended|sweepstakes ended|deadline (?:has )?passed)\b/i.test(body);
  const explicitlyOpen = /\b(enter now|entries? (?:are )?open|giveaway is live|raffle is live|registration is open|register now|enter to win now)\b/i.test(body);

  // The verified entry deadline is authoritative. A product release or article publish
  // date is never passed into this function as an entry-window date.
  if (Number.isFinite(end) && end < now) return { status: "Closed", statusDate: endDate, statusNote: "The verified entry deadline has passed." };
  if (explicitlyClosed) return { status: "Closed", statusDate: Number.isFinite(end) ? endDate : "", statusNote: "The page says entries have closed or winners were selected." };
  if (Number.isFinite(start) && start > now) return { status: "Upcoming", statusDate: startDate, statusNote: "Entries have a verified future opening date." };
  if (Number.isFinite(end) && end >= now) return { status: "Open", statusDate: endDate, statusNote: "The verified deadline has not passed. Entries should be open unless the official page says otherwise." };
  // Once a verified entry-opening date has passed, the draw is treated as Open until
  // an explicit close notice or a verified past deadline is found.
  if (Number.isFinite(start) && start <= now) return { status: "Open", statusDate: "", statusNote: "The verified entry start date has passed; no closing date was published, so the giveaway is treated as ongoing until the page says otherwise." };
  if (explicitlyOpen) return { status: "Open", statusDate: "", statusNote: "The page indicates entries are open, but does not provide a verified deadline." };
  return { status: "Verify", statusDate: "", statusNote: "The giveaway is relevant, but its entry window could not be verified." };
}
async function resolveRaffle(raffle) {
  const page = await fetchPublisherArticle(raffle);
  const pageCanonical = canonicalUrl(page.html, page.url);
  const sourceText = pageText(page.html);
  const metadata = extractPageMetadata(page.html, pageCanonical, raffle);
  const combined = `${raffle.title || ""} ${raffle.summary || ""} ${metadata.pageTitle} ${metadata.pageDescription} ${sourceText}`;
  const relevant = isTcgGiveawayText(combined) && !CRIME_RE.test(combined) && !metadata.cashOnlyPrize;
  if (!relevant) return { relevant: false, sourceUrl: pageCanonical, metadata, bodyText: sourceText };

  let entryUrl = "";
  let entryLinkLabel = "";
  if (entryPageValid(page.url, page.html, raffle) || entryPageValid(pageCanonical, page.html, raffle)) {
    entryUrl = page.url;
    entryLinkLabel = "Verified Pokémon TCG entry page";
  } else {
    const candidates = entryCandidates(page.html, page.url, raffle).slice(0, 5);
    for (const candidate of candidates) {
      try {
        const entryPage = await fetchHtml(candidate.url);
        if (!entryPageValid(entryPage.url, entryPage.html, raffle)) continue;
        entryUrl = entryPage.url;
        entryLinkLabel = candidate.label || "Verified giveaway entry";
        const entryMetadata = extractPageMetadata(entryPage.html, entryPage.url, raffle);
        if (entryMetadata.prize) metadata.prize = entryMetadata.prize;
        if (entryMetadata.startDate) metadata.startDate = entryMetadata.startDate;
        if (entryMetadata.endDate) metadata.endDate = entryMetadata.endDate;
        if (entryMetadata.imageUrl) {
          metadata.imageUrl = entryMetadata.imageUrl;
          metadata.imageType = entryMetadata.imageType;
          metadata.imageUrls = entryMetadata.imageUrls;
        }
        break;
      } catch {
        // Failed or non-HTML destinations are not advertised as entry pages.
      }
    }
  }

  const status = inferStatus(metadata.startDate, metadata.endDate, `${sourceText} ${pageText(page.html)}`);
  const host = (() => { try { return new URL(pageCanonical).hostname.replace(/^www\./, ""); } catch { return ""; } })();
  return {
    relevant: true,
    sourceUrl: pageCanonical,
    entryUrl,
    entryLinkLabel,
    metadata: { ...metadata, siteName: metadata.siteName || raffle.siteName || host, siteUrl: metadata.siteUrl || (() => { try { return new URL(pageCanonical).origin; } catch { return ""; } })() },
    inferredStatus: status,
    bodyText: sourceText
  };
}
function productPageCandidates(html, pageUrl, post) {
  const subject = `${post?.title || ""} ${post?.summary || ""}`;
  const candidates = [];
  const seen = new Set();
  for (const match of String(html || "").matchAll(/<a\b([^>]*)>([\s\S]*?)<\/a>/gi)) {
    const attributes = match[1];
    const href = resolveUrl(attr(attributes, "href") || attr(attributes, "data-href") || attr(attributes, "data-url"), pageUrl);
    if (!href) continue;
    let parsed;
    try { parsed = new URL(href); } catch { continue; }
    if (parsed.hostname === new URL(pageUrl).hostname || isGoogleHost(parsed.hostname)) continue;
    if (/\/(?:news|article|articles|blog|press-release|stories|raffle|giveaway|sweepstakes)(?:\/|$)/i.test(parsed.pathname)) continue;
    const label = stripMarkup(match[2]) || attr(attributes, "aria-label") || attr(attributes, "title");
    const near = stripMarkup(String(html).slice(Math.max(0, match.index - 420), Math.min(String(html).length, match.index + match[0].length + 420)));
    const context = `${label} ${near} ${parsed.pathname} ${subject}`;
    const action = /\b(shop|buy|view product|product details|check price|preorder|pre-order|available at|shop now)\b/i.test(label);
    const genericWords = new Set(["pokemon", "pokémon", "trading", "cards", "tcg", "restock", "back", "stock", "available", "deal", "deals", "price", "release", "new"]);
    const itemWords = subject.toLowerCase().split(/[^a-z0-9]+/).filter((word) => word.length > 3 && !genericWords.has(word));
    const anchorSpecific = `${label} ${parsed.pathname}`.toLowerCase();
    const directItemMatch = itemWords.some((word) => anchorSpecific.includes(word));
    const nearbyItemMatches = itemWords.filter((word) => near.toLowerCase().includes(word)).length;
    const productClue = TCG_PRODUCT_RE.test(context) || /pokemon|pok[eé]mon|booster|elite.trainer|collection|promo.card/i.test(parsed.pathname);
    const retailerOrProductPath = /pokemon|pok[eé]mon|product|products|\/dp\/|\/gp\/product|item|shop/i.test(`${parsed.hostname} ${parsed.pathname}`);
    if (!productClue || !(action || retailerOrProductPath) || (!directItemMatch && nearbyItemMatches < 2)) continue;
    const key = parsed.href.split(/[?#]/)[0];
    if (seen.has(key)) continue;
    seen.add(key);
    candidates.push({ url: parsed.href, score: (action ? 3 : 0) + (retailerOrProductPath ? 2 : 0) + (TCG_PRODUCT_RE.test(`${label} ${parsed.pathname}`) ? 3 : 0) });
  }
  return candidates.sort((a, b) => b.score - a.score).slice(0, 2);
}
async function resolvePostImages(post) {
  const page = await fetchPublisherArticle(post);
  const canonical = canonicalUrl(page.html, page.url);
  const subject = `${post.title || ""} ${post.summary || ""}`;
  const nodes = jsonLdNodes(page.html);
  const product = nodes.filter((node) => typeIncludes(node, "Product"))
    .find((node) => TCG_PRODUCT_RE.test(`${node.name || ""} ${node.description || ""}`)
      && (POKEMON_RE.test(`${node.name || ""} ${node.description || ""}`)
        || (POKEMON_RE.test(subject) && TCG_PRODUCT_RE.test(subject)))) || null;
  const images = extractItemImages(page.html, canonical, subject, "post", null, product);

  // If an article only includes text links to the product, follow up to two relevant
  // retailer product pages and use their structured/large product images.
  if (images.length < 3) {
    const productLinks = productPageCandidates(page.html, canonical, post);
    for (const candidate of productLinks) {
      try {
        const productPage = await fetchHtml(candidate.url);
        const productCanonical = canonicalUrl(productPage.html, productPage.url);
        const productNodes = jsonLdNodes(productPage.html).filter((node) => typeIncludes(node, "Product"));
        const pageDetails = `${titleTag(productPage.html)} ${metaValue(productPage.html, ["og:title", "og:description", "description"])} ${pageText(productPage.html)}`;
        if (!POKEMON_RE.test(pageDetails) || !TCG_PRODUCT_RE.test(pageDetails)) continue;
        const structuredProduct = productNodes.find((node) => TCG_PRODUCT_RE.test(`${node.name || ""} ${node.description || ""}`)
          && (POKEMON_RE.test(`${node.name || ""} ${node.description || ""}`) || POKEMON_RE.test(pageDetails))) || null;
        const productImages = extractItemImages(productPage.html, productCanonical, `${subject} ${pageDetails}`, "post", null, structuredProduct, true);
        images.push(...productImages);
        const deduped = uniqueImages(images);
        images.splice(0, images.length, ...deduped);
        if (images.length >= 3) break;
      } catch (error) {
        console.warn(`Product image lookup skipped: ${candidate.url} // ${error?.message || error}`);
      }
    }
  }
  return { sourceUrl: canonical, siteUrl: (() => { try { return new URL(canonical).origin; } catch { return ""; } })(), images: uniqueImages(images) };
}
async function mapWithConcurrency(items, limit, worker) {
  let nextIndex = 0;
  const workers = Array.from({ length: Math.min(limit, items.length) }, async () => {
    while (nextIndex < items.length) {
      const index = nextIndex++;
      try { await worker(items[index], index); }
      catch (error) { console.warn("PokeDrop discovery worker error:", error?.message || error); }
    }
  });
  await Promise.all(workers);
}
function normalizeImages(value) {
  if (!Array.isArray(value)) return [];
  return uniqueImages(value.map((item) => typeof item === "string" ? ({ url: item, label: "ITEM IMAGE", kind: "product", alt: "" }) : item));
}

// Enrich product/news alert images for the existing regular Drop Finder cards.
const posts = readJson("posts.json", []);
if (Array.isArray(posts) && posts.length) {
  const now = Date.now();
  const candidates = posts.filter((post) => {
    const version = Number(post.imageLookupVersion || 0);
    if (version < RESOLVER_VERSION) return true;
    if (post.imageLookupStatus === "found" && normalizeImages(post.imageUrls).length) return false;
    const last = Date.parse(post.imageLookupAt || "");
    return !Number.isFinite(last) || now - last >= (post.imageLookupStatus === "error" ? 864e5 : 7 * 864e5);
  }).slice(0, MAX_POST_IMAGE_CHECKS_PER_RUN);
  let postImageErrors = 0;
  await mapWithConcurrency(candidates, CONCURRENCY, async (post) => {
    const checkedAt = new Date().toISOString();
    try {
      const resolved = await resolvePostImages(post);
      post.sourceUrl = resolved.sourceUrl || post.sourceUrl || post.url;
      post.siteUrl = resolved.siteUrl || post.siteUrl || "";
      post.imageUrls = resolved.images;
      post.imageLookupStatus = resolved.images.length ? "found" : "not-found";
      post.imageLookupAt = checkedAt;
      post.imageLookupVersion = RESOLVER_VERSION;
      console.log(`Item images (${resolved.images.length}): ${post.title}`);
    } catch (error) {
      post.imageUrls = normalizeImages(post.imageUrls);
      post.imageLookupStatus = "error";
      post.imageLookupAt = checkedAt;
      post.imageLookupVersion = RESOLVER_VERSION;
      post.imageLookupError = String(error?.message || error).slice(0, 160);
      postImageErrors += 1;
    }
  });
  writeJson("posts.json", posts);
  const feedStatus = readJson("feed-status.json", {});
  feedStatus.news ||= {};
  feedStatus.news.itemImageDiscovery = {
    version: RESOLVER_VERSION,
    pagesChecked: candidates.length,
    itemsWithImages: posts.filter((post) => normalizeImages(post.imageUrls).length).length,
    imageErrors: postImageErrors
  };
  writeJson("feed-status.json", feedStatus);
}

// Enrich, revalidate and prune giveaway leads. Old resolver results are not trusted in v4.
const raffles = readJson("raffles.json", []);
if (!Array.isArray(raffles) || !raffles.length) {
  console.log("Raffle discovery: no raffle leads to validate.");
} else {
  for (const raffle of raffles) {
    if (Number(raffle.entryLookupVersion || 0) < RESOLVER_VERSION) {
      raffle.entryUrl = "";
      raffle.entryLinkLabel = "";
      raffle.startDate = "";
      raffle.endDate = "";
      raffle.prize = "";
      raffle.imageUrl = "";
      raffle.imageType = "";
      raffle.imageUrls = [];
      raffle.status = "Verify";
      raffle.statusDate = null;
      raffle.statusNote = "Waiting for v4 giveaway verification; old entry links and dates were not trusted.";
      raffle.qualificationStatus = "pending";
    }
    const brief = `${raffle.title || ""} ${raffle.summary || ""}`;
    if (CRIME_RE.test(brief) || !PROMOTION_RE.test(brief) || isMoneyOnlyPrize(prizeHintFromText(brief))) {
      raffle.qualificationStatus = "rejected";
      raffle.entryLookupStatus = "rejected";
      raffle.entryLookupVersion = RESOLVER_VERSION;
      raffle.entryUrl = "";
    }
  }
  const now = Date.now();
  const candidates = raffles.filter((raffle) => {
    if (Number(raffle.entryLookupVersion || 0) < RESOLVER_VERSION) return true;
    if (raffle.qualificationStatus === "rejected") return false;
    const last = Date.parse(raffle.entryLookupAt || "");
    return !Number.isFinite(last) || now - last >= (raffle.entryLookupStatus === "error" ? 864e5 : 7 * 864e5);
  }).slice(0, MAX_RAFFLE_CHECKS_PER_RUN);
  let lookupErrors = 0;
  let publisherPagesChecked = 0;

  await mapWithConcurrency(candidates, CONCURRENCY, async (raffle) => {
    const checkedAt = new Date().toISOString();
    // Quick rejection before network I/O avoids spending requests on theft reports and cash-only draws.
    const brief = `${raffle.title || ""} ${raffle.summary || ""}`;
    if (CRIME_RE.test(brief) || (!raffle.targetedSearch && !isTcgGiveawayText(brief)) || (!PROMOTION_RE.test(brief) && !raffle.targetedSearch)) {
      raffle.qualificationStatus = "rejected";
      raffle.entryLookupStatus = "rejected";
      raffle.entryLookupAt = checkedAt;
      raffle.entryLookupVersion = RESOLVER_VERSION;
      raffle.entryUrl = "";
      raffle.status = "Verify";
      return;
    }
    try {
      const resolved = await resolveRaffle(raffle);
      raffle.sourceUrl = resolved.sourceUrl || raffle.sourceUrl || raffle.url;
      raffle.entryUrl = resolved.entryUrl || ""; // never carry an unverified legacy URL forward
      raffle.entryLinkLabel = resolved.entryLinkLabel || "";
      raffle.entryLookupStatus = resolved.relevant ? (resolved.entryUrl ? "found" : "not-found") : "rejected";
      raffle.entryLookupAt = checkedAt;
      raffle.entryLookupVersion = RESOLVER_VERSION;
      raffle.lastVerifiedAt = checkedAt;
      raffle.qualificationStatus = resolved.relevant ? "confirmed" : "rejected";
      raffle.entryLookupError = "";
      if (!resolved.relevant) {
        raffle.status = "Verify";
        raffle.statusDate = null;
        raffle.statusNote = "Filtered out: the source page did not confirm a Pokémon TCG card giveaway or raffle.";
      } else {
        const metadata = resolved.metadata || {};
        for (const field of ["siteName", "siteUrl", "pageTitle", "pageDescription", "startDate", "endDate", "prize", "imageUrl", "imageType"]) {
          raffle[field] = metadata[field] || "";
        }
        raffle.imageUrls = normalizeImages(metadata.imageUrls || []);
        const status = resolved.inferredStatus || inferStatus(raffle.startDate, raffle.endDate, resolved.bodyText || "");
        raffle.status = status.status;
        raffle.statusDate = status.statusDate || null;
        raffle.statusNote = status.statusNote;
        raffle.store = storeFromText(`${raffle.title} ${raffle.source} ${raffle.siteName} ${raffle.siteUrl}`, raffle.store);
      }
      publisherPagesChecked += 1;
      console.log(`Giveaway ${raffle.qualificationStatus}: ${raffle.title}`);
    } catch (error) {
      raffle.entryUrl = "";
      raffle.entryLinkLabel = "";
      raffle.entryLookupStatus = "error";
      raffle.entryLookupAt = checkedAt;
      raffle.entryLookupVersion = RESOLVER_VERSION;
      raffle.lastVerifiedAt = checkedAt;
      raffle.qualificationStatus = isTcgGiveawayText(brief) ? "unverified" : "rejected";
      raffle.entryLookupError = String(error?.message || error).slice(0, 180);
      raffle.status = raffle.qualificationStatus === "unverified" ? "Verify" : "Verify";
      raffle.statusDate = null;
      raffle.statusNote = "The publisher page could not be verified. No entry URL or unverified prize image is shown.";
      if (raffle.qualificationStatus === "rejected") lookupErrors += 1;
      else lookupErrors += 1;
    }
  });

  const validRaffles = raffles.filter((raffle) => {
    if (raffle.qualificationStatus === "rejected" || raffle.entryLookupStatus === "rejected") return false;
    const brief = `${raffle.title || ""} ${raffle.summary || ""}`;
    if (CRIME_RE.test(brief)) return false;
    return raffle.qualificationStatus === "confirmed"
      || (raffle.qualificationStatus === "unverified" && isTcgGiveawayText(brief))
      || (raffle.qualificationStatus === "pending" && PROMOTION_RE.test(brief) && (raffle.targetedSearch || isTcgGiveawayText(brief)));
  });
  const rank = { Open: 0, Upcoming: 1, Verify: 2, Closed: 3 };
  validRaffles.sort((a, b) => (rank[a.status] ?? 4) - (rank[b.status] ?? 4) || String(b.date || "").localeCompare(String(a.date || "")));
  writeJson("raffles.json", validRaffles);

  const feedStatus = readJson("feed-status.json", {});
  feedStatus.raffles ||= {};
  feedStatus.raffles.directEntryLinksFound = validRaffles.filter((item) => /^https?:\/\//i.test(item.entryUrl || "")).length;
  feedStatus.raffles.directEntryLinksMissing = validRaffles.filter((item) => !/^https?:\/\//i.test(item.entryUrl || "")).length;
  feedStatus.raffles.entryLookupsThisRun = candidates.length;
  feedStatus.raffles.entryLookupErrors = lookupErrors;
  feedStatus.raffles.qualifiedLeads = validRaffles.length;
  feedStatus.raffles.rejectedLeads = raffles.length - validRaffles.length;
  feedStatus.raffles.discoveryEngine = {
    version: RESOLVER_VERSION,
    publisherPagesChecked,
    prizeDetailsFound: validRaffles.filter((item) => item.prize).length,
    startDatesFound: validRaffles.filter((item) => item.startDate).length,
    endDatesFound: validRaffles.filter((item) => item.endDate).length,
    prizeImagesFound: validRaffles.filter((item) => item.imageUrl && item.imageType === "prize").length,
    rejectedFalsePositives: raffles.length - validRaffles.length,
    entryLinksValidated: validRaffles.filter((item) => item.entryUrl).length
  };
  writeJson("feed-status.json", feedStatus);
  console.log(`Raffle discovery v${RESOLVER_VERSION}: ${candidates.length} checked; ${validRaffles.length} qualified; ${feedStatus.raffles.directEntryLinksFound} verified entry URLs; ${lookupErrors} page errors.`);
}
